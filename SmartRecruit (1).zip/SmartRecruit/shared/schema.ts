import { pgTable, text, serial, integer, boolean, timestamp, real } from "drizzle-orm/pg-core";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";

export const users = pgTable("users", {
  id: serial("id").primaryKey(),
  email: text("email").notNull().unique(),
  name: text("name").notNull(),
  phone: text("phone"),
  userType: text("user_type").notNull(), // 'patient' or 'driver'
  createdAt: timestamp("created_at").defaultNow(),
});

export const ambulances = pgTable("ambulances", {
  id: serial("id").primaryKey(),
  driverId: integer("driver_id").references(() => users.id),
  vehicleNumber: text("vehicle_number").notNull(),
  driverName: text("driver_name").notNull(),
  phone: text("phone").notNull(),
  type: text("type").notNull(), // 'government', 'private', 'independent'
  category: text("category").notNull(), // 'Basic Life Support', 'ICU Equipped', etc.
  latitude: real("latitude"),
  longitude: real("longitude"),
  isAvailable: boolean("is_available").default(true),
  isOnline: boolean("is_online").default(false),
  rating: real("rating").default(4.0),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const emergencyRequests = pgTable("emergency_requests", {
  id: serial("id").primaryKey(),
  patientId: integer("patient_id").references(() => users.id),
  ambulanceId: integer("ambulance_id").references(() => ambulances.id),
  patientName: text("patient_name").notNull(),
  patientPhone: text("patient_phone").notNull(),
  pickupLocation: text("pickup_location").notNull(),
  pickupLatitude: real("pickup_latitude").notNull(),
  pickupLongitude: real("pickup_longitude").notNull(),
  emergencyType: text("emergency_type"),
  status: text("status").notNull().default("pending"), // 'pending', 'accepted', 'en_route', 'completed'
  createdAt: timestamp("created_at").defaultNow(),
  updatedAt: timestamp("updated_at").defaultNow(),
});

export const hospitals = pgTable("hospitals", {
  id: serial("id").primaryKey(),
  name: text("name").notNull(),
  address: text("address").notNull(),
  latitude: real("latitude").notNull(),
  longitude: real("longitude").notNull(),
  phone: text("phone").notNull(),
  specialty: text("specialty").notNull(),
  type: text("type").notNull(), // 'government', 'private'
  rating: real("rating").default(4.0),
  isOpen24_7: boolean("is_open_24_7").default(true),
});

export const insertUserSchema = createInsertSchema(users).omit({
  id: true,
  createdAt: true,
});

export const insertAmbulanceSchema = createInsertSchema(ambulances).omit({
  id: true,
  updatedAt: true,
});

export const insertEmergencyRequestSchema = createInsertSchema(emergencyRequests).omit({
  id: true,
  createdAt: true,
  updatedAt: true,
});

export const insertHospitalSchema = createInsertSchema(hospitals).omit({
  id: true,
});

export type User = typeof users.$inferSelect;
export type InsertUser = z.infer<typeof insertUserSchema>;
export type Ambulance = typeof ambulances.$inferSelect;
export type InsertAmbulance = z.infer<typeof insertAmbulanceSchema>;
export type EmergencyRequest = typeof emergencyRequests.$inferSelect;
export type InsertEmergencyRequest = z.infer<typeof insertEmergencyRequestSchema>;
export type Hospital = typeof hospitals.$inferSelect;
export type InsertHospital = z.infer<typeof insertHospitalSchema>;
