import { createServer, type Server } from "http";
import express, { type Request, type Response } from "express";
import { z } from "zod";
import { storage } from "./storage";
import type { InsertAmbulance } from "../shared/schema";
import { insertAmbulanceSchema } from "../shared/schema";

export function registerRoutes(app: express.Application): Server {

  // Authentication middleware to extract Replit user info
  const extractUserInfo = (req: Request) => {
    const userId = req.headers['x-replit-user-id'] as string;
    const userName = req.headers['x-replit-user-name'] as string;
    const userRoles = req.headers['x-replit-user-roles'] as string;

    if (!userId || !userName) {
      return null;
    }

    // Parse roles - for demo purposes, we'll assign driver role to specific users
    // In a real app, this would come from your database
    const roles = [];
    if (userRoles) {
      roles.push(...userRoles.split(','));
    }

    // For demo: make certain users drivers (you can customize this logic)
    if (userName.toLowerCase().includes('driver') || 
        userName.toLowerCase().includes('ambulance') ||
        userId === 'demo-driver' ||
        Math.random() > 0.5) { // 50% chance for demo purposes
      roles.push('driver');
    }

    return {
      id: userId,
      name: userName,
      roles: Array.from(new Set(roles)) // Remove duplicates
    };
  };

  // Auth routes
  app.get("/api/auth/me", (req: Request, res: Response) => {
    const user = extractUserInfo(req);

    if (!user) {
      return res.json({ user: null });
    }

    res.json({ user });
  });
  // Get all ambulances
  app.get("/api/ambulances", async (req, res) => {
    try {
      const ambulances = await storage.getAllAmbulances();
      res.json(ambulances);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ambulances" });
    }
  });

  // Get ambulance by ID
  app.get("/api/ambulances/:id", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const ambulance = await storage.getAmbulance(id);

      if (!ambulance) {
        return res.status(404).json({ message: "Ambulance not found" });
      }

      res.json(ambulance);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch ambulance" });
    }
  });

  // Create new ambulance
  app.post("/api/ambulances", async (req, res) => {
    try {
      const validatedData = insertAmbulanceSchema.parse(req.body);
      const ambulance = await storage.createAmbulance(validatedData);
      res.status(201).json(ambulance);
    } catch (error) {
      if (error instanceof z.ZodError) {
        res.status(400).json({ message: "Invalid ambulance data", errors: error.errors });
      } else {
        res.status(500).json({ message: "Failed to create ambulance" });
      }
    }
  });

  // Update ambulance location
  app.patch("/api/ambulances/:id/location", async (req, res) => {
    try {
      const id = parseInt(req.params.id);
      const { latitude, longitude } = req.body;

      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }

      const ambulance = await storage.updateAmbulanceLocation(id, latitude, longitude);

      if (!ambulance) {
        return res.status(404).json({ message: "Ambulance not found" });
      }

      res.json(ambulance);
    } catch (error) {
      res.status(500).json({ message: "Failed to update ambulance location" });
    }
  });

  // Get all hospitals
  app.get("/api/hospitals", async (req, res) => {
    try {
      const hospitals = await storage.getAllHospitals();
      res.json(hospitals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch hospitals" });
    }
  });

  // Create emergency request
  app.post("/api/emergency-requests", async (req, res) => {
    try {
      const validatedData = {
        patientName: req.body.patientName,
        patientPhone: req.body.patientPhone,
        pickupLocation: req.body.pickupLocation,
        pickupLatitude: req.body.pickupLatitude,
        pickupLongitude: req.body.pickupLongitude,
        emergencyType: req.body.emergencyType,
        status: req.body.status || "pending"
      };
      const request = await storage.createEmergencyRequest(validatedData);
      res.status(201).json(request);
    } catch (error) {
      res.status(500).json({ message: "Failed to create emergency request" });
    }
  });

  // Get nearby ambulances
  app.get("/api/ambulances/nearby", async (req, res) => {
    try {
      const { latitude, longitude, radius = 10 } = req.query;

      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }

      const ambulances = await storage.getNearbyAmbulances(
        parseFloat(latitude as string),
        parseFloat(longitude as string),
        parseFloat(radius as string)
      );

      res.json(ambulances);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch nearby ambulances" });
    }
  });

  // Get nearby hospitals
  app.get("/api/hospitals/nearby", async (req, res) => {
    try {
      const { latitude, longitude, radius = 10 } = req.query;

      if (!latitude || !longitude) {
        return res.status(400).json({ message: "Latitude and longitude are required" });
      }

      const hospitals = await storage.getNearbyHospitals(
        parseFloat(latitude as string),
        parseFloat(longitude as string),
        parseFloat(radius as string)
      );

      res.json(hospitals);
    } catch (error) {
      res.status(500).json({ message: "Failed to fetch nearby hospitals" });
    }
  });

  const httpServer = createServer(app);
  return httpServer;
}