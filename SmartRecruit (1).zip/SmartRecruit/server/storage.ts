import { users, ambulances, hospitals, emergencyRequests, type User, type InsertUser, type Ambulance, type InsertAmbulance, type Hospital, type InsertHospital, type EmergencyRequest, type InsertEmergencyRequest } from "@shared/schema";

export interface IStorage {
  // User operations
  getUser(id: number): Promise<User | undefined>;
  getUserByEmail(email: string): Promise<User | undefined>;
  createUser(user: InsertUser): Promise<User>;

  // Ambulance operations
  getAmbulance(id: number): Promise<Ambulance | undefined>;
  getAllAmbulances(): Promise<Ambulance[]>;
  createAmbulance(ambulance: InsertAmbulance): Promise<Ambulance>;
  updateAmbulanceLocation(id: number, latitude: number, longitude: number): Promise<Ambulance | undefined>;
  getNearbyAmbulances(latitude: number, longitude: number, radius: number): Promise<Ambulance[]>;

  // Hospital operations
  getHospital(id: number): Promise<Hospital | undefined>;
  getAllHospitals(): Promise<Hospital[]>;
  createHospital(hospital: InsertHospital): Promise<Hospital>;
  getNearbyHospitals(latitude: number, longitude: number, radius: number): Promise<Hospital[]>;

  // Emergency request operations
  getEmergencyRequest(id: number): Promise<EmergencyRequest | undefined>;
  createEmergencyRequest(request: InsertEmergencyRequest): Promise<EmergencyRequest>;
  updateEmergencyRequestStatus(id: number, status: string): Promise<EmergencyRequest | undefined>;
}

export class MemStorage implements IStorage {
  private users: Map<number, User>;
  private ambulances: Map<number, Ambulance>;
  private hospitals: Map<number, Hospital>;
  private emergencyRequests: Map<number, EmergencyRequest>;
  private currentUserId: number;
  private currentAmbulanceId: number;
  private currentHospitalId: number;
  private currentRequestId: number;

  constructor() {
    this.users = new Map();
    this.ambulances = new Map();
    this.hospitals = new Map();
    this.emergencyRequests = new Map();
    this.currentUserId = 1;
    this.currentAmbulanceId = 1;
    this.currentHospitalId = 1;
    this.currentRequestId = 1;

    // Initialize with sample data
    this.initializeSampleData();
  }

  private initializeSampleData() {
    // Sample ambulances
    const sampleAmbulances: InsertAmbulance[] = [
      {
        driverId: 1,
        vehicleNumber: "DL-01-AB-1234",
        driverName: "Dr. Amit Sharma",
        phone: "+91 98765 43210",
        type: "government",
        category: "Emergency Unit",
        latitude: 28.6139,
        longitude: 77.2090,
        isAvailable: true,
        isOnline: true,
        rating: 4.5,
      },
      {
        driverId: 2,
        vehicleNumber: "DL-02-CD-5678",
        driverName: "Ms. Priya Patel",
        phone: "+91 87654 32109",
        type: "private",
        category: "ICU Equipped",
        latitude: 28.6289,
        longitude: 77.2065,
        isAvailable: true,
        isOnline: true,
        rating: 4.8,
      },
      {
        driverId: 3,
        vehicleNumber: "DL-03-EF-9012",
        driverName: "Mr. Suresh Kumar",
        phone: "+91 76543 21098",
        type: "independent",
        category: "Basic Life Support",
        latitude: 28.6329,
        longitude: 77.2194,
        isAvailable: true,
        isOnline: true,
        rating: 4.2,
      },
    ];

    // Sample hospitals
    const sampleHospitals: InsertHospital[] = [
      {
        name: "AIIMS Delhi",
        address: "Ansari Nagar, New Delhi",
        latitude: 28.5672,
        longitude: 77.2100,
        phone: "+91 11 2658 8500",
        specialty: "Oncology, Cardiology, Neurology",
        type: "government",
        rating: 4.9,
        isOpen24_7: true,
      },
      {
        name: "Apollo Hospital, Delhi",
        address: "Mathura Road, New Delhi",
        latitude: 28.5545,
        longitude: 77.1897,
        phone: "+91 11 2692 5858",
        specialty: "Organ Transplant, Cardiac Sciences, Neurosciences",
        type: "private",
        rating: 4.8,
        isOpen24_7: true,
      },
      {
        name: "Fortis Escorts Heart Institute",
        address: "Okhla Road, New Delhi",
        latitude: 28.5692,
        longitude: 77.2314,
        phone: "+91 11 4713 5000",
        specialty: "Cardiology, Cardiac Surgery",
        type: "private",
        rating: 4.7,
        isOpen24_7: true,
      },
      {
        name: "Medanta – The Medicity",
        address: "Sector 38, Gurugram",
        latitude: 28.4495,
        longitude: 77.0421,
        phone: "+91 124 414 4444",
        specialty: "Cardiology, Neurology, Cancer",
        type: "private",
        rating: 4.6,
        isOpen24_7: true,
      },
      {
        name: "Max Super Speciality, Saket",
        address: "Saket, New Delhi",
        latitude: 28.5272,
        longitude: 77.2196,
        phone: "+91 11 2651 5050",
        specialty: "Oncology, Orthopedics, Liver Transplant",
        type: "private",
        rating: 4.6,
        isOpen24_7: true,
      },
      {
        name: "Sir Ganga Ram Hospital",
        address: "Rajinder Nagar, New Delhi",
        latitude: 28.6448,
        longitude: 77.1919,
        phone: "+91 11 2575 6000",
        specialty: "Hematology, Hepatology, Cancer",
        type: "private",
        rating: 4.5,
        isOpen24_7: true,
      },
      {
        name: "BLK-Max Super Speciality Hospital",
        address: "Pusa Road, New Delhi",
        latitude: 28.6414,
        longitude: 77.1654,
        phone: "+91 11 3040 3040",
        specialty: "Oncology, Liver Transplant, Bone Marrow",
        type: "private",
        rating: 4.5,
        isOpen24_7: true,
      },
      {
        name: "Indraprastha Apollo Hospital",
        address: "Sarita Vihar, New Delhi",
        latitude: 28.5626,
        longitude: 77.2864,
        phone: "+91 11 2692 5858",
        specialty: "Transplants, Critical Care, Cardiology",
        type: "private",
        rating: 4.7,
        isOpen24_7: true,
      },
      {
        name: "Venkateshwar Hospital",
        address: "Sector 18A, Dwarka",
        latitude: 28.5934,
        longitude: 77.0477,
        phone: "+91 11 4044 4044",
        specialty: "Pulmonology, Neurosciences, Cancer",
        type: "private",
        rating: 4.4,
        isOpen24_7: true,
      },
      {
        name: "Holy Family Hospital",
        address: "Okhla Road, New Delhi",
        latitude: 28.5673,
        longitude: 77.2410,
        phone: "+91 11 2684 4851",
        specialty: "Pediatrics, Gynecology, Cardiology",
        type: "private",
        rating: 4.3,
        isOpen24_7: true,
      },
      {
        name: "Safdarjung Hospital",
        address: "Ansari Nagar, New Delhi",
        latitude: 28.5671,
        longitude: 77.2100,
        phone: "+91 11 2670 6767",
        specialty: "Trauma, Orthopedics, Burns",
        type: "government",
        rating: 4.2,
        isOpen24_7: true,
      },
      {
        name: "Lok Nayak Hospital (LNJP)",
        address: "Delhi Gate, New Delhi",
        latitude: 28.6396,
        longitude: 77.2270,
        phone: "+91 11 2336 0254",
        specialty: "General Surgery, Emergency, ICU",
        type: "government",
        rating: 4.1,
        isOpen24_7: true,
      },
      {
        name: "Artemis Hospital",
        address: "Sector 51, Gurugram",
        latitude: 28.4433,
        longitude: 77.0930,
        phone: "+91 124 511 1111",
        specialty: "Cancer, Cardiology, Urology",
        type: "private",
        rating: 4.5,
        isOpen24_7: true,
      },
      {
        name: "Primus Super Speciality Hospital",
        address: "Chandragupta Marg, New Delhi",
        latitude: 28.5974,
        longitude: 77.1825,
        phone: "+91 11 4044 4044",
        specialty: "Neurology, Spine, Orthopedics",
        type: "private",
        rating: 4.2,
        isOpen24_7: true,
      },
      {
        name: "Rajiv Gandhi Cancer Institute",
        address: "Sector 5, Rohini",
        latitude: 28.7183,
        longitude: 77.1261,
        phone: "+91 11 4700 1000",
        specialty: "Cancer, Oncology, Palliative Care",
        type: "private",
        rating: 4.6,
        isOpen24_7: true,
      },
      {
        name: "Sharda Hospital",
        address: "Greater Noida",
        latitude: 28.4726,
        longitude: 77.5032,
        phone: "+91 120 466 6666",
        specialty: "Dentistry, Psychiatry, Cardiology",
        type: "private",
        rating: 4.2,
        isOpen24_7: true,
      },
      {
        name: "Deen Dayal Upadhyay Hospital",
        address: "Hari Nagar, New Delhi",
        latitude: 28.6604,
        longitude: 77.1212,
        phone: "+91 11 2579 5225",
        specialty: "Orthopedics, Burns, Emergency",
        type: "government",
        rating: 4.1,
        isOpen24_7: true,
      },
      {
        name: "Batra Hospital & Medical Research Centre",
        address: "Tuglakabad, New Delhi",
        latitude: 28.5144,
        longitude: 77.2434,
        phone: "+91 11 2959 5555",
        specialty: "Nephrology, Cardiology, General Medicine",
        type: "private",
        rating: 4.3,
        isOpen24_7: true,
      },
      {
        name: "Moolchand Medcity",
        address: "Lajpat Nagar, New Delhi",
        latitude: 28.5759,
        longitude: 77.2414,
        phone: "+91 11 4250 0000",
        specialty: "Diabetology, Heart Care, General Surgery",
        type: "private",
        rating: 4.2,
        isOpen24_7: true,
      },
      {
        name: "Kailash Hospital",
        address: "Sector 27, Noida",
        latitude: 28.5696,
        longitude: 77.3285,
        phone: "+91 120 471 8800",
        specialty: "ENT, Pediatrics, Cardiology",
        type: "private",
        rating: 4.2,
        isOpen24_7: true,
      },
    ];

    // Add sample data
    sampleAmbulances.forEach(ambulance => {
      this.createAmbulance(ambulance);
    });

    sampleHospitals.forEach(hospital => {
      this.createHospital(hospital);
    });
  }

  private calculateDistance(lat1: number, lon1: number, lat2: number, lon2: number): number {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  }

  // User operations
  async getUser(id: number): Promise<User | undefined> {
    return this.users.get(id);
  }

  async getUserByEmail(email: string): Promise<User | undefined> {
    return Array.from(this.users.values()).find(user => user.email === email);
  }

  async createUser(insertUser: InsertUser): Promise<User> {
    const id = this.currentUserId++;
    const user: User = { 
      ...insertUser, 
      id,
      createdAt: new Date(),
      phone: insertUser.phone || null,
    };
    this.users.set(id, user);
    return user;
  }

  // Ambulance operations
  async getAmbulance(id: number): Promise<Ambulance | undefined> {
    return this.ambulances.get(id);
  }

  async getAllAmbulances(): Promise<Ambulance[]> {
    return Array.from(this.ambulances.values());
  }

  async createAmbulance(insertAmbulance: InsertAmbulance): Promise<Ambulance> {
    const id = this.currentAmbulanceId++;
    const ambulance: Ambulance = {
      ...insertAmbulance,
      id,
      updatedAt: new Date(),
      driverId: insertAmbulance.driverId || null,
      latitude: insertAmbulance.latitude || null,
      longitude: insertAmbulance.longitude || null,
      isAvailable: insertAmbulance.isAvailable || null,
      isOnline: insertAmbulance.isOnline || null,
      rating: insertAmbulance.rating || null,
    };
    this.ambulances.set(id, ambulance);
    return ambulance;
  }

  async updateAmbulanceLocation(id: number, latitude: number, longitude: number): Promise<Ambulance | undefined> {
    const ambulance = this.ambulances.get(id);
    if (!ambulance) return undefined;

    const updatedAmbulance = {
      ...ambulance,
      latitude,
      longitude,
      updatedAt: new Date(),
    };
    this.ambulances.set(id, updatedAmbulance);
    return updatedAmbulance;
  }

  async getNearbyAmbulances(latitude: number, longitude: number, radius: number): Promise<Ambulance[]> {
    const allAmbulances = Array.from(this.ambulances.values());
    return allAmbulances.filter(ambulance => {
      if (!ambulance.latitude || !ambulance.longitude || !ambulance.isAvailable || !ambulance.isOnline) {
        return false;
      }

      const distance = this.calculateDistance(
        latitude,
        longitude,
        ambulance.latitude,
        ambulance.longitude
      );

      return distance <= radius;
    });
  }

  // Hospital operations
  async getHospital(id: number): Promise<Hospital | undefined> {
    return this.hospitals.get(id);
  }

  async getAllHospitals(): Promise<Hospital[]> {
    return Array.from(this.hospitals.values());
  }

  async createHospital(insertHospital: InsertHospital): Promise<Hospital> {
    const id = this.currentHospitalId++;
    const hospital: Hospital = {
      ...insertHospital,
      id,
      rating: insertHospital.rating || null,
      isOpen24_7: insertHospital.isOpen24_7 || null,
    };
    this.hospitals.set(id, hospital);
    return hospital;
  }

  async getNearbyHospitals(latitude: number, longitude: number, radius: number): Promise<Hospital[]> {
    const allHospitals = Array.from(this.hospitals.values());
    return allHospitals.filter(hospital => {
      const distance = this.calculateDistance(
        latitude,
        longitude,
        hospital.latitude,
        hospital.longitude
      );

      return distance <= radius;
    });
  }

  // Emergency request operations
  async getEmergencyRequest(id: number): Promise<EmergencyRequest | undefined> {
    return this.emergencyRequests.get(id);
  }

  async createEmergencyRequest(insertRequest: InsertEmergencyRequest): Promise<EmergencyRequest> {
    const id = this.currentRequestId++;
    const request: EmergencyRequest = {
      ...insertRequest,
      id,
      status: "pending",
      createdAt: new Date(),
      updatedAt: new Date(),
      patientId: insertRequest.patientId || null,
      ambulanceId: insertRequest.ambulanceId || null,
      emergencyType: insertRequest.emergencyType || null,
    };
    this.emergencyRequests.set(id, request);
    return request;
  }

  async updateEmergencyRequestStatus(id: number, status: string): Promise<EmergencyRequest | undefined> {
    const request = this.emergencyRequests.get(id);
    if (!request) return undefined;

    const updatedRequest = {
      ...request,
      status,
      updatedAt: new Date(),
    };
    this.emergencyRequests.set(id, updatedRequest);
    return updatedRequest;
  }
}

export const storage = new MemStorage();