import { useState, useEffect } from "react";
import { Card, CardContent } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Phone, MapPin, Clock, User, Car, Route } from "lucide-react";
import { useQuery } from "@tanstack/react-query";
import { ref, onValue, off } from "firebase/database";
import { database } from "@/lib/firebase";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import GoogleMap from "@/components/maps/google-map";
import type { Ambulance } from "@shared/schema";

export default function TrackAmbulance() {
  const [ambulanceId, setAmbulanceId] = useState<number | null>(1);
  const [ambulanceLocation, setAmbulanceLocation] = useState<{ lat: number; lng: number } | null>({ lat: 28.6139, lng: 77.2090 });
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>({ lat: 28.6149, lng: 77.2100 });
  const [eta, setEta] = useState<string>("5-7 minutes");
  const [distance, setDistance] = useState<string>("2.3 km");
  const [isSimulating, setIsSimulating] = useState(false);

  // Get ambulance ID from URL params or use demo
  useEffect(() => {
    const urlParams = new URLSearchParams(window.location.search);
    const id = urlParams.get("ambulanceId");
    if (id) {
      setAmbulanceId(parseInt(id));
    } else {
      // Demo mode - start ambulance simulation
      setIsSimulating(true);
      let lat = 28.6139;
      let lng = 77.2090;
      
      const simulationInterval = setInterval(() => {
        lat += 0.0001;
        lng += 0.0001;
        setAmbulanceLocation({ lat, lng });
      }, 2000);
      
      // Stop after 2 minutes
      setTimeout(() => {
        clearInterval(simulationInterval);
        setIsSimulating(false);
      }, 120000);
    }
  }, []);

  // Get user location
  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          // Default to Delhi coordinates
          setUserLocation({ lat: 28.6139, lng: 77.2090 });
        }
      );
    }
  }, []);

  // Get ambulance data
  const { data: ambulance } = useQuery<Ambulance>({
    queryKey: ["/api/ambulances", ambulanceId],
    enabled: !!ambulanceId,
  });

  // Listen to real-time location updates
  useEffect(() => {
    if (!ambulanceId || !database) return;

    const locationRef = ref(database, `ambulances/${ambulanceId}`);
    const unsubscribe = onValue(locationRef, (snapshot) => {
      const data = snapshot.val();
      if (data && data.lat && data.lng) {
        setAmbulanceLocation({ lat: data.lat, lng: data.lng });
      }
    });

    return () => off(locationRef, "value", unsubscribe);
  }, [ambulanceId]);

  const handleCall = () => {
    if (ambulance) {
      window.open(`tel:${ambulance.phone}`);
    }
  };

  const handleEtaCalculated = (etaTime: string, distanceText: string) => {
    setEta(etaTime);
    setDistance(distanceText);
  };

  // Always show demo tracking for hackathon
  if (false) {
    return null;
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Live Ambulance Tracking</h1>
          
          {ambulance && (
            <Card className="mb-8 overflow-hidden">
              {/* Ambulance Header */}
              <div className="bg-emergency-blue text-white p-4">
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <i className="fas fa-ambulance text-xl"></i>
                    <div>
                      <h3 className="font-semibold">{ambulance.driverName}</h3>
                      <p className="text-sm opacity-90">{ambulance.category}</p>
                    </div>
                  </div>
                  <div className="text-right">
                    <p className="text-sm opacity-90">ETA</p>
                    <p className="text-xl font-bold">{eta || "Calculating..."}</p>
                  </div>
                </div>
              </div>
              
              {/* Map */}
              <div className="relative">
                {userLocation && ambulanceLocation && (
                  <GoogleMap
                    center={userLocation}
                    markers={[
                      {
                        lat: userLocation.lat,
                        lng: userLocation.lng,
                        title: "Your Location",
                        icon: "https://maps.google.com/mapfiles/ms/icons/blue-dot.png",
                      },
                      {
                        lat: ambulanceLocation.lat,
                        lng: ambulanceLocation.lng,
                        title: "Ambulance Location",
                        icon: "https://maps.google.com/mapfiles/ms/icons/red-dot.png",
                      },
                    ]}
                    showRoute={{
                      origin: ambulanceLocation,
                      destination: userLocation,
                    }}
                    onEtaCalculated={handleEtaCalculated}
                  />
                )}
                
                {/* Status Overlay */}
                <div className="absolute top-4 left-4 bg-white rounded-lg shadow-lg p-3">
                  <div className="flex items-center space-x-2">
                    <div className="w-3 h-3 bg-emergency-success rounded-full animate-pulse"></div>
                    <span className="text-sm font-medium">Ambulance En Route</span>
                  </div>
                </div>
              </div>
              
              {/* Ambulance Details */}
              <div className="p-6 bg-white">
                <div className="grid grid-cols-1 md:grid-cols-3 gap-6">
                  <div className="text-center">
                    <User className="h-8 w-8 text-emergency-blue mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-800">Driver</h4>
                    <p className="text-sm text-gray-600">{ambulance.driverName}</p>
                    <p className="text-sm text-gray-500">{ambulance.phone}</p>
                  </div>
                  <div className="text-center">
                    <Car className="h-8 w-8 text-emergency-red mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-800">Vehicle</h4>
                    <p className="text-sm text-gray-600">{ambulance.vehicleNumber}</p>
                    <p className="text-sm text-gray-500 capitalize">{ambulance.type}</p>
                  </div>
                  <div className="text-center">
                    <Route className="h-8 w-8 text-emergency-success mx-auto mb-2" />
                    <h4 className="font-semibold text-gray-800">Journey</h4>
                    <p className="text-sm text-gray-600">{distance || "Calculating..."}</p>
                    <p className="text-sm text-gray-500">{eta || "Calculating..."} away</p>
                  </div>
                </div>
                
                <div className="mt-6 flex justify-center">
                  <Button
                    onClick={handleCall}
                    className="bg-emergency-success hover:bg-green-700"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call Driver
                  </Button>
                </div>
              </div>
            </Card>
          )}
        </div>
      </div>

      <MobileNav />
    </div>
  );
}
