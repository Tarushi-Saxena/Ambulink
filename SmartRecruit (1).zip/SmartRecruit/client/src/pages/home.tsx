import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Link } from "wouter";
import { Phone, Search, MapPin, Heart, Building2, Ambulance } from "lucide-react";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

export default function Home() {
  const emergencyContacts = [
    { label: "Ambulance", number: "102" },
    { label: "Police", number: "100" },
    { label: "Fire", number: "101" },
    { label: "Women Helpline", number: "1091" },
  ];

  const quickServices = [
    {
      href: "/find-ambulance",
      title: "Find Nearby Ambulance",
      description: "Locate available ambulances in your area",
      icon: <Search className="h-8 w-8" />,
      color: "emergency-red",
      buttonText: "Search Now",
    },
    {
      href: "/track-ambulance",
      title: "Track Ambulance",
      description: "Real-time tracking of your ambulance",
      icon: <MapPin className="h-8 w-8" />,
      color: "emergency-blue",
      buttonText: "Track Now",
    },
    {
      href: "/first-aid",
      title: "AI First Aid",
      description: "Get instant first aid guidance",
      icon: <Heart className="h-8 w-8" />,
      color: "emergency-success",
      buttonText: "Get Help",
    },
    {
      href: "/hospitals",
      title: "Find Hospitals",
      description: "Locate nearby emergency hospitals",
      icon: <Building2 className="h-8 w-8" />,
      color: "purple-500",
      buttonText: "Find Hospitals",
    },
  ];

  return (
    <div className="min-h-screen bg-white">
      <Header />
      
      {/* Hero Section */}
      <section className="bg-gradient-to-br from-emergency-red to-red-600 text-white py-16">
        <div className="container mx-auto px-4 text-center">
          <h2 className="text-4xl md:text-5xl font-bold mb-6">Emergency Ambulance Service</h2>
          <p className="text-xl mb-8 opacity-90">Quick, reliable ambulance booking and emergency assistance across India</p>
          
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-8">
            <Link href="/find-ambulance">
              <Button
                size="lg"
                className="bg-white text-emergency-red hover:bg-gray-100 text-lg px-8 py-4 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 w-full sm:w-auto"
              >
                <Ambulance className="h-5 w-5 mr-2" />
                Request Ambulance Now
              </Button>
            </Link>
            <Button
              size="lg"
              variant="outline"
              className="border-white text-white hover:bg-white hover:text-emergency-red text-lg px-8 py-4 shadow-lg hover:shadow-xl transform hover:scale-105 transition-all duration-200 w-full sm:w-auto"
              onClick={() => window.open("tel:102")}
            >
              <Phone className="h-5 w-5 mr-2" />
              Emergency: 102
            </Button>
          </div>

          {/* Login Options */}
          <div className="flex flex-col sm:flex-row gap-4 justify-center items-center mb-12">
            <Link href="/patient-login">
              <Button
                size="md"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-emergency-red px-6 py-3 shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 w-full sm:w-auto"
              >
                <Heart className="h-4 w-4 mr-2" />
                Patient Login
              </Button>
            </Link>
            <Link href="/driver-login">
              <Button
                size="md"
                variant="outline"
                className="border-white text-white hover:bg-white hover:text-emergency-red px-6 py-3 shadow-md hover:shadow-lg transform hover:scale-105 transition-all duration-200 w-full sm:w-auto"
              >
                <Ambulance className="h-4 w-4 mr-2" />
                Driver Login
              </Button>
            </Link>
          </div>

          {/* Emergency Contacts */}
          <Card className="max-w-md mx-auto bg-white/10 backdrop-blur-sm border-white/20">
            <CardContent className="p-6">
              <h3 className="text-lg font-semibold mb-4">Emergency Contacts</h3>
              <div className="space-y-2 text-sm">
                {emergencyContacts.map((contact) => (
                  <div key={contact.label} className="flex justify-between">
                    <span>{contact.label}:</span>
                    <span className="font-semibold">{contact.number}</span>
                  </div>
                ))}
              </div>
            </CardContent>
          </Card>
        </div>
      </section>

      {/* Quick Services */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Quick Emergency Services</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
            {quickServices.map((service) => (
              <Card key={service.href} className={`hover:shadow-xl transition-shadow duration-300 border-t-4 border-${service.color}`}>
                <CardContent className="p-6 text-center">
                  <div className={`text-${service.color} mb-4 flex justify-center`}>
                    {service.icon}
                  </div>
                  <h3 className="text-xl font-semibold mb-3 text-gray-800">{service.title}</h3>
                  <p className="text-gray-600 mb-4">{service.description}</p>
                  <Link href={service.href}>
                    <Button className={`bg-${service.color} hover:bg-${service.color}/90 w-full`}>
                      {service.buttonText}
                    </Button>
                  </Link>
                </CardContent>
              </Card>
            ))}
          </div>
        </div>
      </section>

      {/* Features Section */}
      <section className="py-16 bg-gray-50">
        <div className="container mx-auto px-4">
          <h2 className="text-3xl font-bold text-center mb-12 text-gray-800">Why Choose SEVA?</h2>
          
          <div className="grid grid-cols-1 md:grid-cols-3 gap-8">
            <div className="text-center">
              <div className="w-16 h-16 bg-emergency-red rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-clock text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Fast Response</h3>
              <p className="text-gray-600">Quick ambulance booking with real-time tracking and ETA updates</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-emergency-blue rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-shield-alt text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">Verified Services</h3>
              <p className="text-gray-600">All ambulances and drivers are verified and regularly monitored</p>
            </div>
            <div className="text-center">
              <div className="w-16 h-16 bg-emergency-success rounded-full flex items-center justify-center mx-auto mb-4">
                <i className="fas fa-robot text-white text-2xl"></i>
              </div>
              <h3 className="text-xl font-semibold mb-2">AI Assistance</h3>
              <p className="text-gray-600">Get instant first aid guidance powered by advanced AI technology</p>
            </div>
          </div>
        </div>
      </section>

      {/* Footer */}
      <footer className="bg-gray-800 text-white py-12">
        <div className="container mx-auto px-4">
          <div className="grid grid-cols-1 md:grid-cols-4 gap-8">
            <div>
              <div className="flex items-center space-x-2 mb-4">
                <i className="fas fa-ambulance text-emergency-red text-2xl"></i>
                <h3 className="text-xl font-bold">SEVA</h3>
              </div>
              <p className="text-gray-400 text-sm">Emergency ambulance aggregator platform providing quick and reliable emergency medical services across India.</p>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Quick Links</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><Link href="/find-ambulance" className="hover:text-white transition-colors">Find Ambulance</Link></li>
                <li><Link href="/track-ambulance" className="hover:text-white transition-colors">Track Ambulance</Link></li>
                <li><Link href="/first-aid" className="hover:text-white transition-colors">First Aid</Link></li>
                <li><Link href="/hospitals" className="hover:text-white transition-colors">Hospitals</Link></li>
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Emergency Contacts</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                {emergencyContacts.map((contact) => (
                  <li key={contact.label}>{contact.label}: {contact.number}</li>
                ))}
              </ul>
            </div>
            <div>
              <h4 className="font-semibold mb-4">Support</h4>
              <ul className="space-y-2 text-sm text-gray-400">
                <li><a href="#" className="hover:text-white transition-colors">Help Center</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Contact Us</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Privacy Policy</a></li>
                <li><a href="#" className="hover:text-white transition-colors">Terms of Service</a></li>
              </ul>
            </div>
          </div>
          <div className="border-t border-gray-700 mt-8 pt-8 text-center text-sm text-gray-400">
            <p>&copy; 2024 SEVA - Emergency Ambulance Platform. All rights reserved.</p>
          </div>
        </div>
      </footer>

      <MobileNav />
    </div>
  );
}
