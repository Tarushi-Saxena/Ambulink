import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { useQuery } from "@tanstack/react-query";
import { Search, MapPin, Filter } from "lucide-react";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import AmbulanceCard from "@/components/ambulance-card";
import { useToast } from "@/hooks/use-toast";
import type { Ambulance } from "@shared/schema";

export default function FindAmbulance() {
  const [location, setLocation] = useState("");
  const [selectedType, setSelectedType] = useState("all");
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const { toast } = useToast();

  const { data: ambulances, isLoading } = useQuery<Ambulance[]>({
    queryKey: ["/api/ambulances"],
  });

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          toast({
            title: "Location Access",
            description: "Please enable location access for better results",
            variant: "destructive",
          });
        }
      );
    }
  }, [toast]);

  const filteredAmbulances = ambulances?.filter((ambulance) => {
    if (selectedType === "all") return ambulance.isAvailable && ambulance.isOnline;
    return ambulance.isAvailable && ambulance.isOnline && ambulance.type === selectedType;
  }) || [];

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const handleCall = (phone: string) => {
    window.open(`tel:${phone}`);
  };

  const handleBook = (ambulanceId: number) => {
    // Navigate to booking/tracking page
    window.location.href = `/track-ambulance?ambulanceId=${ambulanceId}`;
  };

  const typeFilters = [
    { value: "all", label: "All Types", color: "bg-gray-500" },
    { value: "government", label: "Government", color: "bg-emergency-red" },
    { value: "private", label: "Private", color: "bg-emergency-blue" },
    { value: "independent", label: "Independent", color: "bg-purple-500" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Find Nearby Ambulances</h1>
          
          {/* Location Input */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="flex flex-col sm:flex-row gap-4">
                <div className="flex-1 relative">
                  <MapPin className="absolute left-3 top-3 h-5 w-5 text-gray-400" />
                  <Input
                    placeholder="Enter your location or allow GPS access"
                    value={location}
                    onChange={(e) => setLocation(e.target.value)}
                    className="pl-10"
                  />
                </div>
                <Button className="bg-emergency-blue hover:bg-blue-700">
                  <Search className="h-4 w-4 mr-2" />
                  Find Ambulances
                </Button>
              </div>
              {userLocation && (
                <p className="text-sm text-gray-600 mt-2">
                  <MapPin className="inline h-4 w-4 mr-1" />
                  Using your current location
                </p>
              )}
            </CardContent>
          </Card>

          {/* Type Filters */}
          <div className="flex flex-wrap gap-2 mb-8">
            {typeFilters.map((filter) => (
              <Button
                key={filter.value}
                variant={selectedType === filter.value ? "default" : "outline"}
                size="sm"
                onClick={() => setSelectedType(filter.value)}
                className={selectedType === filter.value ? filter.color : ""}
              >
                {filter.label}
              </Button>
            ))}
          </div>

          {/* Ambulance List */}
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emergency-red mx-auto mb-4"></div>
              <p className="text-gray-600">Loading ambulances...</p>
            </div>
          ) : filteredAmbulances.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <i className="fas fa-search text-gray-400 text-6xl mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">No Ambulances Found</h3>
                <p className="text-gray-600">Try adjusting your location or filter settings</p>
              </CardContent>
            </Card>
          ) : (
            <div className="space-y-4">
              {filteredAmbulances.map((ambulance) => (
                <AmbulanceCard
                  key={ambulance.id}
                  ambulance={ambulance}
                  distance={
                    userLocation && ambulance.latitude && ambulance.longitude
                      ? calculateDistance(
                          userLocation.lat,
                          userLocation.lng,
                          ambulance.latitude,
                          ambulance.longitude
                        )
                      : undefined
                  }
                  onCall={handleCall}
                  onBook={handleBook}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <MobileNav />
    </div>
  );
}
