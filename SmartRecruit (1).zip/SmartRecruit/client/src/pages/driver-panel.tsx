import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Switch } from "@/components/ui/switch";
import { Label } from "@/components/ui/label";
import { Phone, MapPin, Check, X, User, Car, Navigation, Lock } from "lucide-react";
import { ref, set, onValue } from "firebase/database";
import { database } from "@/lib/firebase";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

interface UserData {
  id: string;
  name: string;
  roles: string[];
}

export default function DriverPanel() {
  const [user, setUser] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);
  const [isOnline, setIsOnline] = useState(false);
  const [isSimulating, setIsSimulating] = useState(false);
  const [currentLocation, setCurrentLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [incomingRequest, setIncomingRequest] = useState<any>(null);
  const { toast } = useToast();

  // Mock driver data
  const driverData = {
    id: "driver001",
    name: "Dr. Rajesh Kumar",
    license: "DL-12345",
    phone: "+91 98765 43210",
    vehicle: {
      number: "DL-01-AB-1234",
      type: "Emergency Response Unit",
      category: "Government",
    },
  };

  // Mock incoming request
  const mockRequest = {
    id: "req001",
    patientName: "Priya Sharma",
    location: "Connaught Place, New Delhi",
    distance: "2.3 km",
    type: "Chest Pain",
    phone: "+91 87654 32109",
  };

  useEffect(() => {
    // Check localStorage for driver data
    const driverData = localStorage.getItem('driverData');
    
    if (driverData) {
      const driver = JSON.parse(driverData);
      setUser({
        id: driver.id,
        name: driver.name || "Driver",
        roles: ['driver']
      });
      
      // Get current location
      if (navigator.geolocation) {
        navigator.geolocation.getCurrentPosition(
          (position) => {
            setCurrentLocation({
              lat: position.coords.latitude,
              lng: position.coords.longitude,
            });
          },
          (error) => {
            console.error("Error getting location:", error);
            // Default to Delhi coordinates
            setCurrentLocation({ lat: 28.6139, lng: 77.2090 });
          }
        );
      }

      // Simulate incoming request after 10 seconds
      const timer = setTimeout(() => {
        setIncomingRequest(mockRequest);
      }, 10000);

      setIsLoading(false);
      return () => clearTimeout(timer);
    } else {
      setIsLoading(false);
    }
  }, []);

  const handleOnlineToggle = (checked: boolean) => {
    setIsOnline(checked);
    if (checked) {
      // Auto-start simulation when going online
      handleSimulateMovement();
      toast({
        title: "Status Updated",
        description: "You are now online and available for requests",
      });
    } else {
      setIsSimulating(false);
      toast({
        title: "Status Updated",
        description: "You are now offline",
      });
    }
  };

  const updateLocationInFirebase = (lat: number, lng: number) => {
    if (!database) {
      console.warn("Firebase not configured - location update simulated");
      return;
    }
    
    const locationRef = ref(database, `ambulances/${driverData.id}`);
    set(locationRef, {
      lat,
      lng,
      timestamp: Date.now(),
      isOnline,
    });
  };

  const handleUpdateLocation = () => {
    if (currentLocation) {
      updateLocationInFirebase(currentLocation.lat, currentLocation.lng);
      toast({
        title: "Location Updated",
        description: "Your location has been shared with the system",
      });
    }
  };

  const handleSimulateMovement = () => {
    if (!currentLocation) return;

    setIsSimulating(true);
    let lat = 28.6139; // Start from Delhi coordinates as specified
    let lng = 77.2090; // Start from Delhi coordinates as specified

    const simulationInterval = setInterval(() => {
      lat += 0.0001; // Move northward
      lng += 0.0001; // Move eastward
      
      updateLocationInFirebase(lat, lng);
      setCurrentLocation({ lat, lng });
    }, 2000);

    toast({
      title: "Movement Simulation Started",
      description: "Simulating ambulance movement for demo purposes",
    });

    // Stop simulation after 2 minutes
    setTimeout(() => {
      clearInterval(simulationInterval);
      setIsSimulating(false);
      toast({
        title: "Movement Simulation Stopped",
        description: "Simulation completed",
      });
    }, 120000);
  };

  const handleAcceptRequest = () => {
    setIncomingRequest(null);
    toast({
      title: "Request Accepted",
      description: "You have accepted the emergency request",
    });
  };

  const handleDeclineRequest = () => {
    setIncomingRequest(null);
    toast({
      title: "Request Declined",
      description: "Request has been declined",
    });
  };

  // Show loading state
  if (isLoading) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="animate-spin rounded-full h-8 w-8 border-b-2 border-emergency-blue mx-auto mb-4"></div>
            <p className="text-gray-600">Loading...</p>
          </div>
        </div>
        <MobileNav />
      </div>
    );
  }

  // Show access denied if not authenticated or not a driver
  if (!user || !user.roles?.includes('driver')) {
    return (
      <div className="min-h-screen bg-gray-50">
        <Header />
        <div className="container mx-auto px-4 py-8">
          <div className="max-w-md mx-auto">
            <Card className="text-center">
              <CardContent className="p-8">
                <Lock className="h-12 w-12 text-gray-400 mx-auto mb-4" />
                <h2 className="text-xl font-semibold text-gray-800 mb-2">Access Restricted</h2>
                <p className="text-gray-600 mb-6">
                  This driver panel is only accessible to authenticated ambulance drivers.
                </p>
                {!user ? (
                  <div>
                    <p className="text-sm text-gray-500 mb-4">Please log in to continue</p>
                    <div id="replit-auth-container">
                      <script
                        dangerouslySetInnerHTML={{
                          __html: `
                            if (typeof window !== 'undefined') {
                              const script = document.createElement('script');
                              script.src = 'https://auth.util.repl.co/script.js';
                              script.setAttribute('authed', 'location.reload()');
                              document.getElementById('replit-auth-container').appendChild(script);
                            }
                          `
                        }}
                      />
                    </div>
                  </div>
                ) : (
                  <div>
                    <p className="text-sm text-gray-500 mb-4">
                      Your account doesn't have driver permissions.
                    </p>
                    <Button
                      onClick={() => window.location.href = '/'}
                      className="bg-emergency-blue hover:bg-blue-700"
                    >
                      Go to Home
                    </Button>
                  </div>
                )}
              </CardContent>
            </Card>
          </div>
        </div>
        <MobileNav />
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-20">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Driver Panel</h1>
          
          <Card className="mb-8">
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <User className="h-12 w-12 text-emergency-blue mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-800 mb-2">Ambulance Driver Dashboard</h2>
                <p className="text-gray-600">Manage your ambulance service and respond to emergency requests</p>
              </div>
              
              {/* Driver Status */}
              <div className={`rounded-lg p-6 mb-6 ${isOnline ? 'bg-green-50' : 'bg-red-50'}`}>
                <div className="flex items-center justify-between">
                  <div className="flex items-center space-x-3">
                    <div className={`w-4 h-4 rounded-full ${isOnline ? 'bg-emergency-success animate-pulse' : 'bg-gray-400'}`}></div>
                    <span className="text-lg font-semibold text-gray-800">
                      Status: {isOnline ? 'Online' : 'Offline'}
                    </span>
                  </div>
                  <div className="flex items-center space-x-2">
                    <Label htmlFor="online-toggle" className="text-sm font-medium">
                      {isOnline ? 'Go Offline' : 'Go Online'}
                    </Label>
                    <Switch
                      id="online-toggle"
                      checked={isOnline}
                      onCheckedChange={handleOnlineToggle}
                    />
                  </div>
                </div>
              </div>
              
              {/* Driver Info */}
              <div className="grid grid-cols-1 md:grid-cols-2 gap-6 mb-6">
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-gray-800 mb-2">Driver Information</h4>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>{driverData.name}</p>
                      <p>ID: {driverData.id}</p>
                      <p>License: {driverData.license}</p>
                      <p>{driverData.phone}</p>
                    </div>
                  </CardContent>
                </Card>
                <Card>
                  <CardContent className="p-4">
                    <h4 className="font-semibold text-gray-800 mb-2">Vehicle Information</h4>
                    <div className="space-y-1 text-sm text-gray-600">
                      <p>{driverData.vehicle.number}</p>
                      <p>{driverData.vehicle.type}</p>
                      <p>{driverData.vehicle.category}</p>
                    </div>
                  </CardContent>
                </Card>
              </div>
              
              {/* Location Sharing */}
              <Card className="mb-6">
                <CardContent className="p-6">
                  <h4 className="font-semibold text-gray-800 mb-4">Location Sharing</h4>
                  <div className="flex items-center justify-between mb-4">
                    <div className="flex items-center space-x-2">
                      <MapPin className="h-5 w-5 text-emergency-blue" />
                      <span className="text-sm text-gray-600">
                        {isSimulating ? 'Simulating real-time location' : 'Real-time location available'}
                      </span>
                    </div>
                  </div>
                  <div className="flex space-x-2">
                    <Button
                      onClick={handleUpdateLocation}
                      className="bg-emergency-blue hover:bg-blue-700"
                      disabled={!currentLocation}
                    >
                      <Navigation className="h-4 w-4 mr-2" />
                      Update Location
                    </Button>
                    <Button
                      onClick={handleSimulateMovement}
                      variant="outline"
                      disabled={isSimulating || !currentLocation}
                      className="border-gray-300 hover:bg-gray-50"
                    >
                      <MapPin className="h-4 w-4 mr-2" />
                      {isSimulating ? 'Simulating...' : 'Simulate Movement'}
                    </Button>
                  </div>
                </CardContent>
              </Card>
            </CardContent>
          </Card>
          
          {/* Incoming Request */}
          {incomingRequest && (
            <Card className="border-emergency-red">
              <CardContent className="p-6">
                <div className="flex items-center justify-between mb-4">
                  <h4 className="font-semibold text-gray-800 text-lg">Emergency Request</h4>
                  <span className="bg-emergency-red text-white px-3 py-1 rounded-full text-sm">New</span>
                </div>
                <div className="space-y-2 mb-4">
                  <p className="text-sm text-gray-600">
                    <strong>Patient:</strong> {incomingRequest.patientName}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Location:</strong> {incomingRequest.location}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Distance:</strong> {incomingRequest.distance}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Emergency Type:</strong> {incomingRequest.type}
                  </p>
                  <p className="text-sm text-gray-600">
                    <strong>Contact:</strong> {incomingRequest.phone}
                  </p>
                </div>
                <div className="flex space-x-3">
                  <Button
                    onClick={handleAcceptRequest}
                    className="bg-emergency-success hover:bg-green-700"
                  >
                    <Check className="h-4 w-4 mr-2" />
                    Accept Request
                  </Button>
                  <Button
                    onClick={handleDeclineRequest}
                    variant="outline"
                    className="border-gray-300 hover:bg-gray-50"
                  >
                    <X className="h-4 w-4 mr-2" />
                    Decline
                  </Button>
                  <Button
                    onClick={() => window.open(`tel:${incomingRequest.phone}`)}
                    variant="outline"
                    className="border-emergency-success text-emergency-success hover:bg-emergency-success hover:text-white"
                  >
                    <Phone className="h-4 w-4 mr-2" />
                    Call Patient
                  </Button>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <MobileNav />
    </div>
  );
}
