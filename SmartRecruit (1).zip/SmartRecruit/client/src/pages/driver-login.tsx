import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card";
import { Label } from "@/components/ui/label";
import { Link, useLocation } from "wouter";
import { Ambulance, Phone, MapPin } from "lucide-react";

export default function DriverLogin() {
  const [, navigate] = useLocation();
  const [isLoading, setIsLoading] = useState(false);
  const [formData, setFormData] = useState({
    licenseNumber: "",
    vehicleNumber: "",
    phone: "",
    password: "",
    emergencyContact: "",
  });

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setIsLoading(true);

    // Simulate login process
    setTimeout(() => {
      localStorage.setItem("userType", "driver");
      localStorage.setItem("driverData", JSON.stringify({
        id: "driver_" + Date.now(),
        name: "Driver " + formData.licenseNumber,
        licenseNumber: formData.licenseNumber,
        vehicleNumber: formData.vehicleNumber,
        phone: formData.phone,
        emergencyContact: formData.emergencyContact,
        isOnline: false,
        isAvailable: true,
        location: { lat: 28.6139, lng: 77.2090 } // Delhi center
      }));
      navigate("/driver-panel");
    }, 1000);
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-emergency-blue to-blue-600 flex items-center justify-center p-4">
      <Card className="w-full max-w-md">
        <CardHeader className="text-center">
          <div className="mx-auto mb-4 p-3 bg-emergency-blue rounded-full w-16 h-16 flex items-center justify-center">
            <Ambulance className="h-8 w-8 text-white" />
          </div>
          <CardTitle className="text-2xl font-bold text-emergency-blue">Driver Login</CardTitle>
          <CardDescription>Access your ambulance driver dashboard</CardDescription>
        </CardHeader>
        <CardContent>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="space-y-2">
              <Label htmlFor="licenseNumber">Driver License Number</Label>
              <Input
                id="licenseNumber"
                type="text"
                placeholder="Enter your license number"
                value={formData.licenseNumber}
                onChange={(e) => setFormData({...formData, licenseNumber: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="vehicleNumber">Vehicle Number</Label>
              <Input
                id="vehicleNumber"
                type="text"
                placeholder="Enter ambulance number"
                value={formData.vehicleNumber}
                onChange={(e) => setFormData({...formData, vehicleNumber: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="phone">Phone Number</Label>
              <Input
                id="phone"
                type="tel"
                placeholder="Enter your phone number"
                value={formData.phone}
                onChange={(e) => setFormData({...formData, phone: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="password">Password</Label>
              <Input
                id="password"
                type="password"
                placeholder="Enter your password"
                value={formData.password}
                onChange={(e) => setFormData({...formData, password: e.target.value})}
                required
              />
            </div>

            <div className="space-y-2">
              <Label htmlFor="emergencyContact">Emergency Contact</Label>
              <Input
                id="emergencyContact"
                type="tel"
                placeholder="Emergency contact number"
                value={formData.emergencyContact}
                onChange={(e) => setFormData({...formData, emergencyContact: e.target.value})}
                required
              />
            </div>

            <Button
              type="submit"
              className="w-full bg-emergency-blue hover:bg-blue-700"
              disabled={isLoading}
            >
              {isLoading ? "Logging in..." : "Login as Driver"}
            </Button>
          </form>

          <div className="mt-6 text-center text-sm text-gray-600">
            <p>Don't have an account? <Link href="/driver-signup" className="text-emergency-blue hover:underline font-medium">Sign up here</Link></p>
            <p className="mt-2">Patient instead? <Link href="/patient-login" className="text-emergency-blue hover:underline">Patient Login</Link></p>
            <p className="mt-2">Back to <Link href="/" className="text-emergency-blue hover:underline">Home</Link></p>
          </div>
        </CardContent>
      </Card>
    </div>
  );
}