import { useState, useEffect } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Label } from "@/components/ui/label";
import { useQuery } from "@tanstack/react-query";
import { Search, MapPin } from "lucide-react";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";
import HospitalCard from "@/components/hospital-card";
import GoogleMap from "@/components/maps/google-map";
import { useToast } from "@/hooks/use-toast";
import type { Hospital } from "@shared/schema";

export default function Hospitals() {
  const [location, setLocation] = useState("");
  const [emergencyType, setEmergencyType] = useState("");
  const [userLocation, setUserLocation] = useState<{ lat: number; lng: number } | null>(null);
  const [showMap, setShowMap] = useState(false);
  const { toast } = useToast();

  const { data: hospitals, isLoading } = useQuery<Hospital[]>({
    queryKey: ["/api/hospitals"],
  });

  useEffect(() => {
    if (navigator.geolocation) {
      navigator.geolocation.getCurrentPosition(
        (position) => {
          setUserLocation({
            lat: position.coords.latitude,
            lng: position.coords.longitude,
          });
        },
        (error) => {
          console.error("Error getting location:", error);
          toast({
            title: "Location Access",
            description: "Please enable location access for better results",
            variant: "destructive",
          });
        }
      );
    }
  }, [toast]);

  const calculateDistance = (lat1: number, lon1: number, lat2: number, lon2: number) => {
    const R = 6371; // Radius of the Earth in km
    const dLat = (lat2 - lat1) * Math.PI / 180;
    const dLon = (lon2 - lon1) * Math.PI / 180;
    const a = Math.sin(dLat / 2) * Math.sin(dLat / 2) +
      Math.cos(lat1 * Math.PI / 180) * Math.cos(lat2 * Math.PI / 180) *
      Math.sin(dLon / 2) * Math.sin(dLon / 2);
    const c = 2 * Math.atan2(Math.sqrt(a), Math.sqrt(1 - a));
    return R * c;
  };

  const filteredHospitals = hospitals?.filter((hospital) => {
    if (!emergencyType || emergencyType === "all") return true;
    
    // Map emergency types to specialties
    const emergencyToSpecialty: { [key: string]: string[] } = {
      "Cardiac Emergency": ["cardiology", "cardiac", "heart", "cardiovascular"],
      "Trauma/Accident": ["trauma", "emergency", "accident", "orthopedics", "surgery", "bone"],
      "Neurological": ["neurology", "neurosciences", "neuro", "spine", "brain"],
      "Pediatric Emergency": ["pediatrics", "pediatric", "child"],
      "General Emergency": ["emergency", "general", "icu", "critical care"]
    };
    
    const specialtyKeywords = emergencyToSpecialty[emergencyType] || [emergencyType.toLowerCase()];
    
    // Check if hospital specialty array contains any matching keywords
    return hospital.specialty.some(spec => 
      specialtyKeywords.some(keyword => 
        spec.toLowerCase().includes(keyword)
      )
    );
  }) || [];

  const sortedHospitals = userLocation
    ? filteredHospitals.sort((a, b) => {
        const distanceA = calculateDistance(userLocation.lat, userLocation.lng, a.latitude, a.longitude);
        const distanceB = calculateDistance(userLocation.lat, userLocation.lng, b.latitude, b.longitude);
        return distanceA - distanceB;
      })
    : filteredHospitals;

  const handleCall = (phone: string) => {
    window.open(`tel:${phone}`);
  };

  const handleGetDirections = (hospital: Hospital) => {
    const url = `https://www.google.com/maps/dir/?api=1&destination=${hospital.latitude},${hospital.longitude}&travelmode=driving`;
    window.open(url, "_blank");
  };

  const emergencyTypes = [
    "Cardiac Emergency",
    "Trauma/Accident", 
    "Neurological",
    "Pediatric Emergency",
    "General Emergency",
  ];

  // Create map markers for hospitals
  const mapMarkers = sortedHospitals.map(hospital => ({
    lat: hospital.latitude,
    lng: hospital.longitude,
    title: hospital.name,
    icon: hospital.type === 'government' ? 
      'https://maps.google.com/mapfiles/ms/icons/red-dot.png' : 
      'https://maps.google.com/mapfiles/ms/icons/blue-dot.png'
  }));

  // Add user location marker if available
  if (userLocation) {
    mapMarkers.push({
      lat: userLocation.lat,
      lng: userLocation.lng,
      title: "Your Location",
      icon: 'https://maps.google.com/mapfiles/ms/icons/green-dot.png'
    });
  }

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-4xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">Find Emergency Hospitals</h1>
          
          {/* Filter Controls */}
          <Card className="mb-8">
            <CardContent className="p-6">
              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div>
                  <Label htmlFor="location" className="block text-sm font-medium text-gray-700 mb-2">
                    Location
                  </Label>
                  <div className="relative">
                    <MapPin className="absolute left-3 top-3 h-4 w-4 text-gray-400" />
                    <Input
                      id="location"
                      placeholder="Enter location"
                      value={location}
                      onChange={(e) => setLocation(e.target.value)}
                      className="pl-9"
                    />
                  </div>
                </div>
                <div>
                  <Label htmlFor="emergency-type" className="block text-sm font-medium text-gray-700 mb-2">
                    Emergency Type
                  </Label>
                  <Select value={emergencyType} onValueChange={setEmergencyType}>
                    <SelectTrigger>
                      <SelectValue placeholder="Select emergency type" />
                    </SelectTrigger>
                    <SelectContent>
                      <SelectItem value="all">All Types</SelectItem>
                      {emergencyTypes.map((type) => (
                        <SelectItem key={type} value={type}>
                          {type}
                        </SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <div className="flex items-end gap-2">
                  <Button className="flex-1 bg-emergency-blue hover:bg-blue-700">
                    <Search className="h-4 w-4 mr-2" />
                    Find Hospitals
                  </Button>
                  <Button 
                    variant={showMap ? "default" : "outline"}
                    onClick={() => setShowMap(!showMap)}
                    className="px-4"
                  >
                    <MapPin className="h-4 w-4 mr-1" />
                    {showMap ? "List" : "Map"}
                  </Button>
                </div>
              </div>
              {userLocation && (
                <p className="text-sm text-gray-600 mt-2">
                  <MapPin className="inline h-4 w-4 mr-1" />
                  Using your current location
                </p>
              )}
            </CardContent>
          </Card>

          {/* Hospital List/Map */}
          {isLoading ? (
            <div className="text-center py-12">
              <div className="animate-spin rounded-full h-12 w-12 border-b-2 border-emergency-blue mx-auto mb-4"></div>
              <p className="text-gray-600">Loading hospitals...</p>
            </div>
          ) : sortedHospitals.length === 0 ? (
            <Card>
              <CardContent className="p-12 text-center">
                <i className="fas fa-hospital text-gray-400 text-6xl mb-4"></i>
                <h3 className="text-xl font-semibold text-gray-800 mb-2">No Hospitals Found</h3>
                <p className="text-gray-600">Try adjusting your location or emergency type</p>
              </CardContent>
            </Card>
          ) : showMap ? (
            <Card>
              <CardContent className="p-6">
                <GoogleMap
                  center={userLocation || { lat: 28.6139, lng: 77.2090 }} // Default to Delhi
                  zoom={12}
                  markers={mapMarkers}
                />
                <div className="mt-4 grid grid-cols-1 md:grid-cols-2 gap-4 max-h-96 overflow-y-auto">
                  {sortedHospitals.slice(0, 6).map((hospital) => (
                    <HospitalCard
                      key={hospital.id}
                      hospital={hospital}
                      distance={
                        userLocation
                          ? calculateDistance(
                              userLocation.lat,
                              userLocation.lng,
                              hospital.latitude,
                              hospital.longitude
                            )
                          : undefined
                      }
                      onCall={handleCall}
                      onGetDirections={handleGetDirections}
                    />
                  ))}
                </div>
              </CardContent>
            </Card>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
              {sortedHospitals.map((hospital) => (
                <HospitalCard
                  key={hospital.id}
                  hospital={hospital}
                  distance={
                    userLocation
                      ? calculateDistance(
                          userLocation.lat,
                          userLocation.lng,
                          hospital.latitude,
                          hospital.longitude
                        )
                      : undefined
                  }
                  onCall={handleCall}
                  onGetDirections={handleGetDirections}
                />
              ))}
            </div>
          )}
        </div>
      </div>

      <MobileNav />
    </div>
  );
}
