import { useState } from "react";
import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Textarea } from "@/components/ui/textarea";
import { Label } from "@/components/ui/label";
import { Send, Bot, AlertTriangle } from "lucide-react";
import { getFirstAidAdvice } from "@/lib/gemini";
import { useToast } from "@/hooks/use-toast";
import Header from "@/components/layout/header";
import MobileNav from "@/components/layout/mobile-nav";

export default function FirstAid() {
  const [symptoms, setSymptoms] = useState("");
  const [advice, setAdvice] = useState("");
  const [isLoading, setIsLoading] = useState(false);
  const { toast } = useToast();

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    
    if (!symptoms.trim()) {
      toast({
        title: "Missing Information",
        description: "Please describe the emergency situation",
        variant: "destructive",
      });
      return;
    }

    setIsLoading(true);
    setAdvice("");

    try {
      const response = await getFirstAidAdvice(symptoms);
      setAdvice(response);
    } catch (error) {
      console.error("Error getting first aid advice:", error);
      toast({
        title: "Error",
        description: "Failed to get first aid advice. Please try again or call emergency services.",
        variant: "destructive",
      });
    } finally {
      setIsLoading(false);
    }
  };

  const emergencyNumbers = [
    { service: "Ambulance", number: "102" },
    { service: "Police", number: "100" },
    { service: "Fire", number: "101" },
  ];

  return (
    <div className="min-h-screen bg-gray-50">
      <Header />
      
      <div className="container mx-auto px-4 py-8">
        <div className="max-w-2xl mx-auto">
          <h1 className="text-3xl font-bold text-center mb-8 text-gray-800">AI First Aid Assistant</h1>
          
          {/* Emergency Warning */}
          <Card className="mb-8 border-emergency-red">
            <CardContent className="p-6">
              <div className="flex items-start space-x-3">
                <AlertTriangle className="h-6 w-6 text-emergency-red mt-1 flex-shrink-0" />
                <div>
                  <h3 className="font-semibold text-emergency-red mb-2">Emergency Disclaimer</h3>
                  <p className="text-sm text-gray-700">
                    This AI assistant provides general first aid guidance only. For serious emergencies, 
                    call emergency services immediately. Always seek professional medical help when in doubt.
                  </p>
                </div>
              </div>
            </CardContent>
          </Card>

          {/* Quick Emergency Numbers */}
          <div className="grid grid-cols-3 gap-4 mb-8">
            {emergencyNumbers.map((emergency) => (
              <Button
                key={emergency.service}
                variant="outline"
                className="h-20 flex flex-col border-emergency-red text-emergency-red hover:bg-emergency-red hover:text-white"
                onClick={() => window.open(`tel:${emergency.number}`)}
              >
                <span className="text-lg font-bold">{emergency.number}</span>
                <span className="text-sm">{emergency.service}</span>
              </Button>
            ))}
          </div>

          {/* Main Form */}
          <Card>
            <CardContent className="p-8">
              <div className="text-center mb-8">
                <Bot className="h-12 w-12 text-emergency-success mx-auto mb-4" />
                <h2 className="text-2xl font-semibold text-gray-800 mb-2">Emergency First Aid Guidance</h2>
                <p className="text-gray-600">Describe your emergency situation and get instant AI-powered first aid instructions</p>
              </div>
              
              <form onSubmit={handleSubmit} className="space-y-6">
                <div>
                  <Label htmlFor="symptoms" className="block text-sm font-medium text-gray-700 mb-2">
                    Describe the emergency situation
                  </Label>
                  <Textarea
                    id="symptoms"
                    rows={4}
                    value={symptoms}
                    onChange={(e) => setSymptoms(e.target.value)}
                    placeholder="E.g., Patient has chest pain, difficulty breathing, unconscious after fall..."
                    className="resize-none"
                  />
                </div>
                
                <Button
                  type="submit"
                  disabled={isLoading}
                  className="w-full bg-emergency-success hover:bg-green-700"
                >
                  {isLoading ? (
                    <div className="flex items-center">
                      <div className="animate-spin rounded-full h-4 w-4 border-b-2 border-white mr-2"></div>
                      Getting Instructions...
                    </div>
                  ) : (
                    <>
                      <Send className="h-4 w-4 mr-2" />
                      Get First Aid Instructions
                    </>
                  )}
                </Button>
              </form>
            </CardContent>
          </Card>

          {/* AI Response */}
          {advice && (
            <Card className="mt-8 border-emergency-success">
              <CardContent className="p-6">
                <div className="flex items-start space-x-3">
                  <Bot className="h-6 w-6 text-emergency-success mt-1 flex-shrink-0" />
                  <div className="flex-1">
                    <h3 className="font-semibold text-gray-800 mb-2">AI First Aid Response:</h3>
                    <div className="text-sm text-gray-700 space-y-2 whitespace-pre-wrap">
                      {advice}
                    </div>
                    <div className="mt-4 p-3 bg-red-50 rounded-lg border border-red-200">
                      <p className="text-emergency-red text-sm font-medium">
                        ⚠️ This is for emergency reference only. Always call professional medical help immediately.
                      </p>
                    </div>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </div>
      </div>

      <MobileNav />
    </div>
  );
}
