import { GoogleGenerativeAI } from "@google/generative-ai";

const apiKey = import.meta.env.VITE_GEMINI_API_KEY;

export async function getFirstAidAdvice(symptoms: string): Promise<string> {
  // Check if API key is available
  if (!apiKey || apiKey.trim() === "") {
    return getStaticFirstAidAdvice(symptoms);
  }

  try {
    const genAI = new GoogleGenerativeAI(apiKey);
    const model = genAI.getGenerativeModel({ model: "gemini-2.5-flash" });
    
    const prompt = `You are an emergency medical assistant. A person is describing symptoms: "${symptoms}". 
    
    Provide ONLY 4-5 key first aid instructions that can be performed by a non-medical person while waiting for professional help. 
    
    Format your response as numbered points (1-5 maximum). Each point should be ONE short sentence or action.
    
    Example format:
    1. Call 102 immediately
    2. Keep person calm and sitting upright
    3. Loosen tight clothing
    4. Monitor breathing continuously
    5. Give aspirin if not allergic
    
    IMPORTANT: Keep each instruction under 10 words. Be extremely concise and actionable.`;

    const result = await model.generateContent(prompt);
    const response = await result.response;
    return response.text();
  } catch (error) {
    console.error("Error getting first aid advice:", error);
    return getStaticFirstAidAdvice(symptoms);
  }
}

// Fallback static first aid advice when AI is unavailable
function getStaticFirstAidAdvice(symptoms: string): string {
  const lowerSymptoms = symptoms.toLowerCase();
  
  if (lowerSymptoms.includes("chest pain") || lowerSymptoms.includes("heart attack")) {
    return `1. Call 102 immediately
2. Keep person calm and sitting upright
3. Loosen tight clothing around chest
4. Give aspirin if not allergic
5. Monitor breathing continuously`;
  }
  
  if (lowerSymptoms.includes("unconscious") || lowerSymptoms.includes("unresponsive")) {
    return `1. Call 102 immediately
2. Check if person is breathing
3. Place in recovery position if breathing
4. Clear airway of obstructions
5. Begin CPR if not breathing`;
  }
  
  if (lowerSymptoms.includes("bleeding") || lowerSymptoms.includes("cut") || lowerSymptoms.includes("wound")) {
    return `1. Call 102 immediately
2. Apply direct pressure to wound
3. Elevate injured area above heart
4. Do not remove embedded objects
5. Keep person lying down`;
  }

  // Generic advice for other symptoms
  return `1. Call 102 immediately
2. Keep person calm and comfortable
3. Monitor breathing and consciousness
4. Do not give food or water
5. Stay with person until help arrives`;
}