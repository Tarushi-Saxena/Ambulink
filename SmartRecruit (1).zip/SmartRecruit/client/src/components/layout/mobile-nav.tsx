import { Button } from "@/components/ui/button";
import { Home, Search, MapPin, Heart, Building, Car } from "lucide-react";
import { useState, useEffect } from "react";

interface UserData {
  id: string;
  name: string;
  roles: string[];
}

export default function MobileNav() {
  const [user, setUser] = useState<UserData | null>(null);
  const currentPath = window.location.pathname;

  useEffect(() => {
    // Check localStorage for driver or patient data
    const driverData = localStorage.getItem('driverData');
    const patientData = localStorage.getItem('patientData');
    
    if (driverData) {
      const driver = JSON.parse(driverData);
      setUser({
        id: driver.id,
        name: driver.name || "Driver",
        roles: ['driver']
      });
    } else if (patientData) {
      const patient = JSON.parse(patientData);
      setUser({
        id: patient.id,
        name: patient.name || "Patient",
        roles: ['patient']
      });
    }
  }, []);

  const baseNavItems = [
    { path: "/", icon: Home, label: "Home" },
    { path: "/find-ambulance", icon: Search, label: "Find" },
    { path: "/track-ambulance", icon: MapPin, label: "Track" },
    { path: "/first-aid", icon: Heart, label: "First Aid" },
    { path: "/hospitals", icon: Building, label: "Hospitals" },
  ];

  // Only show driver panel if user is authenticated and has driver role
  const navItems = user?.roles?.includes('driver') 
    ? [...baseNavItems, { path: "/driver-panel", icon: Car, label: "Driver" }]
    : baseNavItems;

  return (
    <nav className="fixed bottom-0 left-0 right-0 bg-white border-t shadow-lg md:hidden z-50">
      <div className="flex justify-around items-center py-2 px-1">
        {navItems.map((item) => {
          const Icon = item.icon;
          const isActive = currentPath === item.path;

          return (
            <Button
              key={item.path}
              variant="ghost"
              size="sm"
              className={`flex flex-col items-center p-2 min-w-0 flex-1 ${
                isActive ? "text-emergency-blue" : "text-gray-600"
              }`}
              onClick={() => window.location.href = item.path}
            >
              <Icon className="h-4 w-4 mb-1" />
              <span className="text-xs truncate">{item.label}</span>
            </Button>
          );
        })}
      </div>
    </nav>
  );
}