import { Link, useLocation } from "wouter";
import { Button } from "@/components/ui/button";
import { Phone, Menu, X, User, LogOut, Plus } from "lucide-react";
import { useState, useEffect } from "react";

interface UserData {
  id: string;
  name: string;
  roles: string[];
}

export default function Header() {
  const [location] = useLocation();
  const [isMobileMenuOpen, setIsMobileMenuOpen] = useState(false);
  const [user, setUser] = useState<UserData | null>(null);
  const [isLoading, setIsLoading] = useState(true);

  useEffect(() => {
    // Check localStorage for driver or patient data
    const driverData = localStorage.getItem('driverData');
    const patientData = localStorage.getItem('patientData');
    
    if (driverData) {
      const driver = JSON.parse(driverData);
      setUser({
        id: driver.id,
        name: driver.name || "Driver",
        roles: ['driver']
      });
    } else if (patientData) {
      const patient = JSON.parse(patientData);
      setUser({
        id: patient.id,
        name: patient.name || "Patient",
        roles: ['patient']
      });
    }
    setIsLoading(false);
  }, []);

  const handleLogout = () => {
    localStorage.removeItem('driverData');
    localStorage.removeItem('patientData');
    setUser(null);
    window.location.href = '/';
  };

  const isDriver = user?.roles?.includes('driver');
  
  const navItems = [
    { href: "/", label: "Home", icon: "fas fa-home" },
    { href: "/find-ambulance", label: "Find Ambulance", icon: "fas fa-search-location" },
    { href: "/track-ambulance", label: "Track", icon: "fas fa-map-marker-alt" },
    { href: "/first-aid", label: "First Aid", icon: "fas fa-first-aid" },
    { href: "/hospitals", label: "Hospitals", icon: "fas fa-hospital" },
    ...(isDriver ? [{ href: "/driver-panel", label: "Driver Panel", icon: "fas fa-user-md" }] : []),
  ];

  return (
    <>
      <header className="bg-white shadow-sm border-b sticky top-0 z-50">
        {/* Header content */}
        <div className="container mx-auto px-4 py-4">
          <div className="flex items-center justify-between">
            <div className="flex items-center space-x-2">
              <div className="w-8 h-8 bg-emergency-red rounded-full flex items-center justify-center">
                <i className="fas fa-ambulance text-white text-sm"></i>
              </div>
              <h1 className="text-xl font-bold text-emergency-red">SEVA</h1>
            </div>

            <nav className="hidden md:flex space-x-6">
              {navItems.map((item) => (
                <Link
                  key={item.href}
                  href={item.href}
                  className={`text-gray-700 hover:text-gray-900 transition-colors ${
                    location === item.href ? "font-semibold" : ""
                  }`}
                >
                  {item.label}
                </Link>
              ))}
            </nav>

            <div className="flex items-center space-x-4">
              {user ? (
                <div className="flex items-center space-x-3">
                  <div className="flex items-center space-x-2">
                    <User className="h-4 w-4 text-gray-600" />
                    <span className="text-sm font-medium text-gray-700">{user.name}</span>
                    {isDriver && <span className="text-xs bg-blue-100 text-blue-700 px-2 py-1 rounded">Driver</span>}
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={handleLogout}
                    className="border-gray-300 text-gray-700 hover:bg-gray-50"
                  >
                    <LogOut className="h-4 w-4 mr-2" />
                    Logout
                  </Button>
                </div>
              ) : (
                <div className="flex items-center space-x-2">
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.location.href = "/patient-login"}
                    className="text-gray-700 border-gray-300 hover:bg-gray-50"
                  >
                    <User className="h-4 w-4 mr-2" />
                    Patient Login
                  </Button>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => window.location.href = "/driver-login"}
                    className="text-blue-700 border-blue-300 hover:bg-blue-50"
                  >
                    <User className="h-4 w-4 mr-2" />
                    Driver Login
                  </Button>
                </div>
              )}

              <Button
                variant="outline"
                size="sm"
                className="border-emergency-red text-emergency-red hover:bg-emergency-red hover:text-white"
                onClick={() => window.open("tel:108")}
              >
                <Phone className="h-4 w-4 mr-2" />
                <span className="hidden sm:inline">Emergency: </span>108
              </Button>

              <button
                className="md:hidden text-gray-700"
                onClick={() => setIsMobileMenuOpen(!isMobileMenuOpen)}
              >
                {isMobileMenuOpen ? <X className="h-6 w-6" /> : <Menu className="h-6 w-6" />}
              </button>
            </div>
          </div>
        </div>
      </header>

      {/* Mobile Menu Overlay */}
      {isMobileMenuOpen && (
        <div className="fixed inset-0 bg-black bg-opacity-50 z-40 md:hidden">
          <div className="fixed top-0 right-0 h-full w-64 bg-white shadow-lg transform transition-transform">
            <div className="p-4">
              <button
                onClick={() => setIsMobileMenuOpen(false)}
                className="absolute top-4 right-4 text-gray-500"
              >
                <X className="h-6 w-6" />
              </button>
              <nav className="mt-8 space-y-4">
                {navItems.map((item) => (
                  <Link
                    key={item.href}
                    href={item.href}
                    className={`block py-2 px-4 rounded-lg transition-colors ${
                      location === item.href
                        ? "bg-emergency-red text-white"
                        : "text-gray-700 hover:bg-gray-100"
                    }`}
                    onClick={() => setIsMobileMenuOpen(false)}
                  >
                    <i className={`${item.icon} mr-3`}></i>
                    {item.label}
                  </Link>
                ))}
              </nav>
            </div>
          </div>
        </div>
      )}
    </>
  );
}