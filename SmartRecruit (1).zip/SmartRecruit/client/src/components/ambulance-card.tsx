import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Check, Star } from "lucide-react";
import type { Ambulance } from "@shared/schema";

interface AmbulanceCardProps {
  ambulance: Ambulance;
  distance?: number;
  onCall: (phone: string) => void;
  onBook: (ambulanceId: number) => void;
}

export default function AmbulanceCard({ ambulance, distance, onCall, onBook }: AmbulanceCardProps) {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "government":
        return "border-emergency-red";
      case "private":
        return "border-emergency-blue";
      case "independent":
        return "border-purple-500";
      default:
        return "border-gray-300";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "government":
        return "bg-emergency-red";
      case "private":
        return "bg-emergency-blue";
      case "independent":
        return "bg-purple-500";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <Card className={`hover:shadow-xl transition-shadow duration-300 border-l-4 ${getTypeColor(ambulance.type)}`}>
      <CardContent className="p-6">
        <div className="flex flex-col sm:flex-row justify-between items-start sm:items-center">
          <div className="flex items-center space-x-4 mb-4 sm:mb-0">
            <div className={`w-16 h-16 ${getTypeIcon(ambulance.type)} rounded-lg flex items-center justify-center`}>
              <i className="fas fa-ambulance text-white text-2xl"></i>
            </div>
            <div>
              <h3 className="text-lg font-semibold text-gray-800">{ambulance.driverName}</h3>
              <p className="text-sm text-gray-600 capitalize">{ambulance.type} • {ambulance.category}</p>
              <div className="flex items-center space-x-4 text-sm text-gray-500">
                <div className="flex items-center">
                  {[...Array(5)].map((_, i) => (
                    <Star
                      key={i}
                      className={`h-4 w-4 ${
                        i < Math.floor(ambulance.rating || 0) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                      }`}
                    />
                  ))}
                  <span className="ml-1">({ambulance.rating || 0})</span>
                </div>
                {distance && <span>• {distance.toFixed(1)} km away</span>}
              </div>
            </div>
          </div>
          <div className="flex flex-col sm:flex-row gap-2 w-full sm:w-auto">
            <Button
              variant="outline"
              size="sm"
              onClick={() => onCall(ambulance.phone)}
              className="text-emergency-success border-emergency-success hover:bg-emergency-success hover:text-white"
            >
              <Phone className="h-4 w-4 mr-2" />
              Call
            </Button>
            <Button
              size="sm"
              onClick={() => onBook(ambulance.id)}
              className="bg-emergency-blue hover:bg-blue-700"
            >
              <Check className="h-4 w-4 mr-2" />
              Book Now
            </Button>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
