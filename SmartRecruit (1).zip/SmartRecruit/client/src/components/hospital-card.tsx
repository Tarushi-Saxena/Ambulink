import { Button } from "@/components/ui/button";
import { Card, CardContent } from "@/components/ui/card";
import { Phone, Navigation, Star } from "lucide-react";
import type { Hospital } from "@shared/schema";

interface HospitalCardProps {
  hospital: Hospital;
  distance?: number;
  onCall: (phone: string) => void;
  onGetDirections: (hospital: Hospital) => void;
}

export default function HospitalCard({ hospital, distance, onCall, onGetDirections }: HospitalCardProps) {
  const getTypeColor = (type: string) => {
    switch (type) {
      case "government":
        return "border-emergency-red";
      case "private":
        return "border-emergency-blue";
      default:
        return "border-gray-300";
    }
  };

  const getTypeIcon = (type: string) => {
    switch (type) {
      case "government":
        return "bg-emergency-red";
      case "private":
        return "bg-emergency-blue";
      default:
        return "bg-gray-500";
    }
  };

  return (
    <Card className={`hover:shadow-xl transition-shadow duration-300 border-l-4 ${getTypeColor(hospital.type)}`}>
      <CardContent className="p-6">
        <div className="flex items-start space-x-4">
          <div className={`w-16 h-16 ${getTypeIcon(hospital.type)} rounded-lg flex items-center justify-center flex-shrink-0`}>
            <i className="fas fa-hospital text-white text-2xl"></i>
          </div>
          <div className="flex-1">
            <h3 className="text-lg font-semibold text-gray-800 mb-2">{hospital.name}</h3>
            <p className="text-sm text-gray-600 mb-2 capitalize">{hospital.type} • {hospital.specialty}</p>
            <div className="flex items-center space-x-4 text-sm text-gray-500 mb-3">
              <div className="flex items-center">
                {[...Array(5)].map((_, i) => (
                  <Star
                    key={i}
                    className={`h-4 w-4 ${
                      i < Math.floor(hospital.rating || 0) ? "fill-yellow-400 text-yellow-400" : "text-gray-300"
                    }`}
                  />
                ))}
                <span className="ml-1">({hospital.rating || 0})</span>
              </div>
              {distance && <span>• {distance.toFixed(1)} km</span>}
              <span className="text-emergency-success">Open 24/7</span>
            </div>
            <div className="flex space-x-2">
              <Button
                variant="outline"
                size="sm"
                onClick={() => onCall(hospital.phone)}
                className="text-emergency-success border-emergency-success hover:bg-emergency-success hover:text-white"
              >
                <Phone className="h-4 w-4 mr-1" />
                Call
              </Button>
              <Button
                size="sm"
                onClick={() => onGetDirections(hospital)}
                className="bg-emergency-blue hover:bg-blue-700"
              >
                <Navigation className="h-4 w-4 mr-1" />
                Directions
              </Button>
            </div>
          </div>
        </div>
      </CardContent>
    </Card>
  );
}
