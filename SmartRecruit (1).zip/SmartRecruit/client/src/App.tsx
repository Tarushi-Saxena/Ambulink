import { Switch, Route } from "wouter";
import { queryClient } from "./lib/queryClient";
import { QueryClientProvider } from "@tanstack/react-query";
import { Toaster } from "@/components/ui/toaster";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/not-found";
import Home from "@/pages/home";
import FindAmbulance from "@/pages/find-ambulance";
import TrackAmbulance from "@/pages/track-ambulance";
import FirstAid from "@/pages/first-aid";
import Hospitals from "@/pages/hospitals";
import DriverPanel from "@/pages/driver-panel";
import DriverLogin from "@/pages/driver-login";
import DriverSignup from "@/pages/driver-signup";
import PatientLogin from "@/pages/patient-login";
import PatientSignup from "@/pages/patient-signup";

function Router() {
  return (
    <Switch>
      <Route path="/" component={Home} />
      <Route path="/find-ambulance" component={FindAmbulance} />
      <Route path="/track-ambulance" component={TrackAmbulance} />
      <Route path="/first-aid" component={FirstAid} />
      <Route path="/hospitals" component={Hospitals} />
      <Route path="/driver-panel" component={DriverPanel} />
      <Route path="/driver-login" component={DriverLogin} />
      <Route path="/driver-signup" component={DriverSignup} />
      <Route path="/patient-login" component={PatientLogin} />
      <Route path="/patient-signup" component={PatientSignup} />
      <Route component={NotFound} />
    </Switch>
  );
}

function App() {
  return (
    <QueryClientProvider client={queryClient}>
      <TooltipProvider>
        <Toaster />
        <Router />
      </TooltipProvider>
    </QueryClientProvider>
  );
}

export default App;
